package com.example.contactos;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    private EditText edt1,edt2,edt3;
    private Button btn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        edt1=(EditText)findViewById(R.id.editU);
        edt2=(EditText)findViewById(R.id.editC);
        edt3=(EditText)findViewById(R.id.editE);
        btn=(Button)findViewById(R.id.btnEntrar);

        btn.setOnClickListener(this);

    }
    @Override
    public void onClick(View v){
        String usuario= edt1.getText().toString();
        String contra= edt2.getText().toString();
        String edad= edt3.getText().toString();

        switch (v.getId()){
            case R.id.btnEntrar:
                if(usuario.equals("guadalupe")&&contra.equals("12345")&&edad.equals("21")){
                    Intent intent = new Intent(this, MainActivity2.class);
                    startActivity(intent);
                }
                break;
            default:
                break;
        }

        switch (v.getId()){
            case R.id.btnEntrar:
                if(usuario.equals("francisco")&&contra.equals("12345")&&edad.equals("21")){
                    Intent intent = new Intent(this, MainActivity2.class);
                    startActivity(intent);
                }
                break;
            default:
                break;
        }
    }
}