package com.example.contactos;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity2 extends AppCompatActivity implements View.OnClickListener {
    private EditText edt1,edt2;
    private Button btn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        edt1=(EditText)findViewById(R.id.editU2);
        edt2=(EditText)findViewById(R.id.editC2);
        btn=(Button)findViewById(R.id.btnEntrar2);

        btn.setOnClickListener(this);

    }

    @Override
    public void onClick(View v){
        String usuario= edt1.getText().toString();
        String contra= edt2.getText().toString();

        switch (v.getId()){
            case R.id.btnEntrar2:
                if(usuario.equals("guadalupe")&&contra.equals("12345")){
                    Intent intent = new Intent(this, MainActivity4.class);
                    startActivity(intent);
                }else{
                    Toast.makeText(this, "Datos incorrectos", Toast.LENGTH_SHORT).show();
                }

                break;
            default:
                break;
        }
            switch (v.getId()) {
                case R.id.btnEntrar2:
                    if (usuario.equals("francisco") && contra.equals("12345")) {
                        Intent intent = new Intent(this, MainActivity3.class);
                        startActivity(intent);
                    }else{
                        Toast.makeText(this, "Datos incorrectos", Toast.LENGTH_SHORT).show();
                    }
                    break;
                default:
                    break;
            }
        }
}